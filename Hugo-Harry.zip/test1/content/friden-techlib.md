+++
title = "TODO: Unique Page Title"
description = "TODO: meta-description"
date = 2017-10-17T14:34:17+11:00
draft = true
+++
<div class="row">
  <div class="col-md-12">
    <h1 class="text-center"><a href="friden000" class="btn btn-sm btn-info pull-left" role="button">Back to Friden Overview</a>Friden EC 130 Calculator</h1>
  </div>
  <ul class="nav nav-tabs">
    <li><a href="/friden-ec130-00/#Description">Description</a></li>
    <li><a href="/friden-ec130-00/#Technology">Technology</a></li>
    <li><a href="/friden-ec130-00/#Photos">Photos</a></li>
    <li><a href="/friden-ec130-00/#MachineLog">Machine Log</a></li>
    <li class="active"><a href="#DataLinks" data-toggle="tab">Data and Links</a></li>
  </ul>
  <div class="tab-content">
    <div class="tab-pane active" id="DataLinks">  <!-- Tab 1 Description -->
      <div class="col-md-12">
        <p>&nbsp;</p>
        <table class="table">
        <tbody>
        <tr>
          <td><a href="fridenEC130-1dsn.html"><strong>Friden EC-130</strong></a></td>
          <td></td>
        </tr>
        <tr>
          <td><a href="Bialik1965-1969_3430095_SRIdisplay.pdf">US Patent 3430095</a></td>
          <td>Display subsystem developed by SRI for the EC-130</td>
        </tr>
        <tr>
          <td><a href="Ragan1963-1970_3523282_DrumCalc.pdf">US Patent 3523282</a></td>
          <td>Patent for Ragens original drum based EC-130 prototype</td>
        </tr>
        <tr>
          <td><a href="Ragan1963-1970_3546676_DrumCalc.pdf">US Patent 3546676</a></td>
          <td>Patent for the EC-130 4-counter machine as put into production</td>
        </tr>
        <tr>
          <td><a href="Ragan1970-1973_3778778_RecircMemCalc.pdf">US Patent 3778778</a></td>
          <td>Further patent on EC-130 architecture</td>
        </tr>
        <tr>
          <td><a href="EC130_SignalsLogicConst_print.pdf">EC-130 "Computer Printout"</a></td>
          <td>An original document containing a structured complete logical and circuit description of the 4-counter EC-130.</br>Unfortunately, the logical structure is obscure and this puzzle is still to be decoded.</td>
        </tr>
        <tr>
          <td><a href="Friden130PSU.pdf">EC-130 Power Supply</a></td>
          <td>Reverse engineered circuit of the EC-130 power supply</td>
        </tr>
        <tr>
          <td><a href="5DEP1_CRTdatasheet.pdf">CRT Datasheet</a></td>
          <td>Manufacturer's data sheet for the 5DEP1 CRT used in the EC-130</td>
        </tr>
        <tr>
          <td><a href="Friden130Ad_1964.pdf">Friden Advertisement</a></td>
          <td>Advertisement from 1964, just after the introduction of the EC-130</td>
        </tr>
        </tbody>
        </table>
        <table class="table">
        <tbody>
        <tr>
          <td><a href="friden1162-1dsn.html"><strong>Friden 1162</strong></a></td>
          <td></td>
        </tr>
        <tr>
          <td><a href="Friden_1160_1162_manual.pdf">Friden 1160/1162 User Manual</a></td>
          <td>Original User Manual for 1160/1162 machines</td>
        </tr>
        <tr>
          <td><a href="Ragen1969-1971_3597600_Friden1160.pdf">US Patent 3597600</a></td>
          <td>Friden 1160 patent</td>
        </tr>
        </tbody>
        </table>
        <table class="table">
        <tbody>
        <tr>
          <td><a href="friden1203-1dsn.html"><strong>Friden 1203</strong></a></td>
          <td></td>
        </tr>
        <tr>
          <td></td>
          <td>... nothing yet ...</td>
        </tr>
        </tbody>
        </table>
        <table class="table">
        <tbody>
        <tr>
          <td><a href="friden.html"><strong>Friden General and Other Models</strong></a></td>
          <td></td>
        </tr>
        <tr>
          <td><a href="data/Singer_1115_service.pdf">Singer 1115 Service Manual</a></td>
          <td>Complete technical data including principles of operation, timing &amp; circuits </br>Also has pinouts of HD31xx series ICs</td>
        </tr>
        </tbody>
        </table>
      </div>  <!-- Col -->
    </div>  <!-- Tab pane-->
  </div>  <!-- Tab content -->
</div>  <!-- row -->
