+++
title = "TODO: Unique Page Title"
description = "TODO: meta-description"
date = 2017-10-16T13:44:37+11:00
draft = true
+++

<div class="row">
  <h1 class="text-center">Latest Updates and Log</h1>
  <div class="col-md-12">
  <p></p>
  <div class="panel-group" id="accordion">
  <div class="panel panel-default">
  <div class="panel-heading">
  <p class="panel-title">
  <a data-toggle="collapse" data-parent="#accordion" href="#log0002"><strong>Update: May 2015<span class="caret">
</span></strong></a>
</p>
</div>
  <div id="log0002" class="panel-collapse collapse in">
  <div class="panel-body">
  <p class="text-justify"><strong>Wang LOCI-2 Calculator</strong> entry has been added</p>
  <p class="text-justify"><strong>Monrobot XI Computer</strong> entry has been added</p>
</div>
</div>
</div>
</div>
  <div class="panel panel-default">
  <div class="panel-heading">
  <p class="panel-title"><a data-toggle="collapse" data-parent="#accordion" href="#log0001"><strong>Site Launch <span class="caret">
</span></strong></a></p>
</div>
  <div id="log0001" class="panel-collapse collapse">
  <div class="panel-body">
  <p class="text-justify">After nearly twelve months of interrupted effort, the collection of machines and technical data has been organised and documented to produce the DoPECC site. Hopefully, this will be the beginning of a site where information can be collected, developed and organised to assist in keeping first-generation electronic calculators in working order.</p>
</div>
</div>
</div>
</div>
</div>
