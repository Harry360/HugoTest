+++
title = "DoPECC: Vintage Transistor Calculators"
description = "Transistor-based electronic calculators of the 1960s - overview"
date = 2017-10-14T20:37:41+11:00
draft = true
+++

<h1 class="text-center">The Dawn of Personal Electronic Calculators</h1>
<div class="row">
  <div class="col-md-8">
  <p>&nbsp;</p>


The dawn period for electronic calculators begins in the early 1960s and ends in the early 1970s. Prior to the 1960s, mechanical calculators had reached a remarkable level of sophistication and some could even extract square roots but all were large, heavy, expensive and required precision care and maintenance. These machines were widely used by well-funded groups but were largely out of the reach of modest organisations and individuals.

Two lines of development matured and converged in the early 1960s, setting the stage for the dawn of personal electronic calculators.

The first development was the progress of digital computer technology from its stumbling infancy in the late 1940s to a confident adolescence at the end of the 1950s. Techniques for electronic logic, calculation and memory had matured and engineers familiar with these techniques were beginning to seek new applications. It is interesting that many of the original ground-breaking electronic calculators were not produced in the R&D divisions of established calculator and computer companies but by individuals or small teams working independently in start-up environments.

The second development was the progress of the solid stage transistor from laboratory experiment to cheap, reliable commercial product. Before transistors were readily available digital logic circuits were built with large, hot, unreliable vacuum tubes. The resulting machines were large, power hungry and maintenance-intensive, limiting their use to well-funded organisations. The arrival of reliable inexpensive transistors at the start of the 1960's allowed creative engineers to apply digital logic techniques to the production of new, better and smaller calculating machines

The names of these first visionary engineers are little known but they and their first machines should be better recognised:

- Norbert Kitz / [ANITA Mk8](http://www.vintagecalculators.com/html/anita_mk_8.html)
- William Kahn, Roy Reach & David Shapiro / [Mathatron](http://www.oldcalculatormuseum.com/c-math8-48m.html)
- [Massimo Rinaldi](http://it.wikipedia.org/wiki/Massimo_Rinaldi_(inventore)) / [IME 84](calcat/ime/IME.html)
- Robert Ragen / [Friden EC-130](calcat/friden/fridenEC130-1dsn.html)
- [Stanley Frankel](https://en.wikipedia.org/wiki/Stan_Frankel) / [SCM 240-SR](http://www.oldcalculatormuseum.com/scm240sr.html)
- [Pier Giorgio Perotto](http://www.piergiorgioperotto.it) / [Olivetti Programma 101](http://www.silab.it/frox/p101/_index.html)
- [An Wang /](https://en.wikipedia.org/wiki/An_Wang) [LOCI calculators](calcat/wang/wangLOCI2-1dsn.html)

These machines were the start of a revolution that put unprecedented levels of calculating power into the hands of individuals. Imaginative and skilled people were now able to focus on ideas and development, rather than becoming bogged down in the mechanics of calculation.

The dawn period for calculators is defined here as the period when the machines were constructed with individual diodes, transistors and (later) basic integrated circuits. First-generation pure diode-transistor machines typically had around 500 transistors and over 1500 diodes. Circuits were complex but the design can be fully deduced from an example machine, given enough time and care. Construction of these machines required much skilled labour and was done with a high standard of workmanship. Internally, these machines display care in design and pride in the standard of construction. All of these factors tended to limit the number of manufacturers who were able to produce such machines and the dawn period sees a relatively small number of high-quality machines and manufacturers.

The dawn period for calculators was brought to an end by the development of integrated circuits. Integrated circuits allowed many transistors to be placed on a silicon chip, producing a small, reliable and ever-cheaper electronic functional block. Small-Scale Integration (SSI) developed slowly through the 1960s and was used in second-generation machines of the late-dawn era, enabling them to become more sophisticated but also smaller and simpler. The electronic functions of SSI chips were very basic and the fundamental design of such machines remains available by analysis of an example machine. Design and construction quality remained high.

Medium-Scale Integration (MSI) became possible in the late 1960s and allowed increasing numbers of functional units to be placed on a chip. By the end of the 1960s third-generation machines began to appear where six, five or even fewer chips could hold the logic of the entire calculator. The design and construction effort shifted from machine building to chip design and manufacture. As the chip companies became the centres for design innovation and manufacturing skill, design information was increasingly hidden inside their chips. Calculators became smaller but more sophisticated, while their physical construction became an ever-simpler assembly of ever-fewer parts. These parts were increasingly complex "black boxes" whose internal design was hidden and unknown, meaning that even if the external circuit of such a calculator was fully traced, it would simply show connections between unknown black boxes. Such a circuit tracing gives little or no information about how the calculator actually works.

The dawn era of electronic calculators was ended by Large-Scale Integration (LSI), which became viable at the end of the 1960s. In LSI calculators the entire circuit was contained in one chip. All of the complexity was now purchased from the chip manufacturer and as chip manufacturing volumes grew, prices fell. Almost any electrical manufacturer could buy LSI chips and assemble calculators. Calculator companies sprang up like mushrooms in the early 1970s and relentless competition drove prices into a steep downwards spiral. Calculators became increasingly ubiquitous and cheap, they were constructed and used like commodities and it was not economic to diagnose or repair them. In any case, electronic calculator design was no longer comprehensible to anyone except the chip designers.

The dawn period had ended by the early 1970s. It had lasted for about ten years and it saw electronic calculators progress from high-priced, cutting edge engineering and craftsmanship to mainstream, mass-produced consumer products.
</div>

<div class="col-md-4">
  <h3 class="text-center text-info">DoPECC's Calculators</h3>
  <div id="MainMenu">
  <div class="list-group panel">
  <a href="#brother" class="list-group-item list-group-item-info" data-toggle="collapse" data-parent="#MainMenu">Brother <span class="caret">
</span></a>
  <div class="collapse" id="brother"><a href="calcat/brother/brother.html" class="list-group-item list-group-item-info">Brother Overview</a> <a href="calcat/brother/brotherPC512-1dsn.html" class="list-group-item">Brother Pro Cal 512</a> <a href="calcat/brother/brotherPC310-1dsn.html" class="list-group-item">Brother 310 Multiplier</a></div>
  <a href="#burroughs" class="list-group-item list-group-item-info" data-toggle="collapse" data-parent="#MainMenu">Burroughs <span class="caret">
</span></a>
  <div class="collapse" id="burroughs"><a href="calcat/burroughs/burroughs.html" class="list-group-item list-group-item-info">Burroughs Overview</a> <a href="calcat/burroughs/burroughsC3300-1dsn.html" class="list-group-item">Burroughs B3300</a> <a href="calcat/burroughs/burroughsC3317-1dsn.html" class="list-group-item">Burroughs B3317</a> <a href="calcat/burroughs/burroughsC7203-1dsn.html" class="list-group-item">Burroughs B7203</a></div>
  <a href="#casio" class="list-group-item list-group-item-info" data-toggle="collapse" data-parent="#MainMenu">Casio&nbsp;<span class="caret">
</span></a>
  <div class="collapse" id="casio"><a href="calcat/casio/casio.html" class="list-group-item list-group-item-info">Casio Overview</a> <a href="calcat/casio/casioAL1000-1dsn.html" class="list-group-item">Casio AL-1000</a> <a href="calcat/casio/casioAL2000-1dsn.html" class="list-group-item">Casio AL-2000</a></div>
  <a href="#friden" class="list-group-item list-group-item-info" data-toggle="collapse" data-parent="#MainMenu">Friden <span class="caret">
</span></a>
  <div class="collapse" id="friden"><a href="/friden-000" class="list-group-item list-group-item-info">Friden Overview</a> <a href="calcat/friden/fridenEC130-1dsn.html" class="list-group-item">Friden EC 130</a> <a href="calcat/friden/friden1162-1dsn.html" class="list-group-item">Friden 1162</a> <a href="calcat/friden/friden1203-1dsn.html" class="list-group-item">Friden 1203</a></div>
  <a href="#homemade" class="list-group-item list-group-item-info" data-toggle="collapse" data-parent="#MainMenu">Home-made <span class="caret">
</span></a>
  <div class="collapse" id="homemade"><a href="calcat/homemade/homemade.html" class="list-group-item list-group-item-info">Home Made Overview</a> <a href="calcat/homemade/homemade.html" class="list-group-item">Digicalc</a></div>
  <a href="#ime" class="list-group-item list-group-item-info" data-toggle="collapse" data-parent="#MainMenu">IME <span class="caret">
</span></a>
  <div class="collapse" id="ime"><a href="calcat/ime/IME.html" class="list-group-item list-group-item-info">IME Overview</a> <a href="calcat/ime/IME86S-1dsn.html" class="list-group-item">IME 86 S</a></div>
  <a href="#monroe" class="list-group-item list-group-item-info" data-toggle="collapse" data-parent="#MainMenu">Monroe <span class="caret">
</span></a>
  <div class="collapse" id="monroe"><a href="calcat/monroe/monroe.html" class="list-group-item list-group-item-info">Monroe Overview</a> <a href="calcat/monroe/monroe950-1dsn.html" class="list-group-item">Monroe 950</a></div>
  <a href="#olympia" class="list-group-item list-group-item-info" data-toggle="collapse" data-parent="#MainMenu">Olympia <span class="caret">
</span></a>
  <div class="collapse" id="olympia"><a href="calcat/olympia/olympia.html" class="list-group-item list-group-item-info">Olympia Overview</a> <a href="calcat/olympia/olympiaRAE415-1dsn.html" class="list-group-item">Olympia RAE 4/15</a> <a href="calcat/olympia/olympiaRAE4302-1dsn.html" class="list-group-item">Olympia RAE 4/30-2</a> <a href="calcat/olympia/olympiaICR412-1dsn.html" class="list-group-item">Olympia ICR-412</a> <a href="calcat/olympia/olympiaCD400-1dsn.html" class="list-group-item">Olympia CD 400</a></div>
  <a href="#sanyo" class="list-group-item list-group-item-info" data-toggle="collapse" data-parent="#MainMenu">Sanyo <span class="caret">
</span></a>
  <div class="collapse" id="sanyo"><a href="calcat/sanyo/sanyo.html" class="list-group-item list-group-item-info">Sanyo Overview</a> <a href="calcat/sanyo/sanyoICC82D-1dsn.html" class="list-group-item">Sanyo ICC-82D</a></div>
  <a href="#sharp" class="list-group-item list-group-item-info" data-toggle="collapse" data-parent="#MainMenu">Sharp <span class="caret">
</span></a>
  <div class="collapse" id="sharp"><a href="calcat/sharp/sharp.html" class="list-group-item list-group-item-info">Sharp Overview</a> <a href="calcat/sharp/sharpCS20A-1dsn.html" class="list-group-item">Sharp CS-20 A</a></div>
  <a href="#soemtron" class="list-group-item list-group-item-info" data-toggle="collapse" data-parent="#MainMenu">Soemtron <span class="caret">
</span></a>
  <div class="collapse" id="soemtron"><a href="calcat/soemtron/soemtron.html" class="list-group-item list-group-item-info">Soemtron Overview</a> <a href="calcat/soemtron/soemtron220-1dsn.html" class="list-group-item">Soemtron 220</a></div>
  <a href="#wang" class="list-group-item list-group-item-info" data-toggle="collapse" data-parent="#MainMenu">Wang <span class="caret">
</span></a>
  <div class="collapse" id="wang"><a href="calcat/wang/wang.html" class="list-group-item list-group-item-info">Wang Overview</a> <a href="calcat/wang/wangLOCI2-1dsn.html" class="list-group-item">Wang LOCI-2</a> <a href="calcat/wang/wang360e-1dsn.html" class="list-group-item">Wang 360E</a> <a href="calcat/wang/wang360se-1dsn.html" class="list-group-item">Wang 360SE</a> <a href="calcat/wang/wang700A-1dsn.html" class="list-group-item">Wang 700A</a> <a href="calcat/wang/wang452-1dsn.html" class="list-group-item">Wang 452-1</a></div>
</div>
</div>
  <div class="panel panel-info">
  <div class="panel-body">
  <img src="images/calcs/friden/EC130-A-i.jpg" alt="Friden EC-130 Calculator" class="img-responsive">
</div>
  <div class="panel-footer">
  <p><a html="calcat/friden/fridenEC130-1dsn.html"><strong>Friden EC 130</strong></a> One of the first of the Dawn Age machines to market, in 1963</p>
</div>
</div>
  <p>
</p>
</div>
</div>
