+++
title = "TODO: Unique Page Title"
description = "TODO: meta-description"
date = 2017-10-16T13:42:14+11:00
draft = true
+++

# About the DoPECC Site

<div class="row">
  <div class="col-md-12">
  <p></p>
  <p class="text-justify">This site is a private effort to share an interest in early electronic technology with fellow enthusiasts and those with a general interest in the subject.</p>
  <p class="text-justify">The machines and the related technical data are both becoming harder to find and many examples are no doubt being lost. The internet provides a means to store and then share this information across a global audience.</p>
  <p class="text-justify">The site is also intended to be a conduit for information and a place where information may be deposited and shared by those who may have items that may be of interest to collectors everywhere. </p>
  <p class="text-justify">Information that is particularly sought includes: </p>
  <ul><li>Circuit Diagrams and Technical Manuals for any machines on this site</li><ul><li>Friden EC 130 and EC 132 circuits are especially wanted</li><li>Sharp Hayakawa circuits for transistor and early IC machines are particularly wanted</li></ul><li>Information about Ai Electronics ABC 24 and ABC 26 Computers</li><ul><li>Any and all original software</li><li>Any and all circuits and technical manuals</li></ul></ul>
  <p></p>
  <h2 class="text-center">Contact DoPECC</h2>
  <p>New information, comments, stories and anything else of interest may be sent to <strong>harry at dopecc dot net</strong></p>
  <p></p>
</div>
</div>
