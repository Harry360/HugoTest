+++
title = "DoPECC: Technical Library"
description = "Information and data about vintage transistor calculators and computers"
date = 2017-10-16T13:35:43+11:00
draft = true
+++

# Early Calculator & Computer Technical Library

<div class="row">
  <div class="col-md-12">
  <p></p>
  <p class="text-justify">In the course of analysing and restoring these machines, a technical library has been accumulated. In many cases the information has been difficult to find and in other cases it is the result of laborious reverse engineering. Some of the information is specific to individual machines while other information is more generic and describes components or technologies.</p>
  <p class="text-justify">The Technical Library is a repository for this information, as a service to other collectors and restorers of vintage electronics and for the information of anyone else interested. Information specific to machines is catalogued by machine manufacturer. More general information is in a separate catalogue, according to technology. </p>
  <p class="text-justify">Donations of material are most welcome. Please send information via the details on the About/Contact link.</p>
</div>
</div>

<div class="row">
  <div class="col-md-4">
  <h3 class="text-center text-info">Calculator-Specific Data</h3>
  <div id="MainMenu">
  <div class="list-group panel">
  <a href="calcat/brother/brother-techlib.html" class="list-group-item list-group-item-info">Brother Data Page <span class="glyphicon glyphicon-chevron-right">
</span></a>
  <a href="calcat/burroughs/burroughs-techlib.html" class="list-group-item list-group-item-info">Burroughs Data Page <span class="glyphicon glyphicon-chevron-right">
</span></a>
  <a href="calcat/casio/casio-techlib.html" class="list-group-item list-group-item-info">Casio Data Page <span class="glyphicon glyphicon-chevron-right">
</span></a>
  <a href="calcat/friden/friden-techlib.html" class="list-group-item list-group-item-info">Friden Data Page <span class="glyphicon glyphicon-chevron-right">
</span></a>
  <a href="calcat/homemade/homemade.html" class="list-group-item list-group-item-info">Home-Made Data Page <span class="glyphicon glyphicon-chevron-right">
</span></a>
  <a href="calcat/ime/IME-techlib.html" class="list-group-item list-group-item-info">IME Data Page <span class="glyphicon glyphicon-chevron-right">
</span></a>
  <a href="calcat/monroe/monroe-techlib.html" class="list-group-item list-group-item-info">Monroe Data Page <span class="glyphicon glyphicon-chevron-right">
</span></a>
  <a href="calcat/olympia/olympia-techlib.html" class="list-group-item list-group-item-info">Olympia Data Page <span class="glyphicon glyphicon-chevron-right">
</span></a>
  <a href="calcat/sanyo/sanyo-techlib.html" class="list-group-item list-group-item-info">Sanyo Data Page <span class="glyphicon glyphicon-chevron-right">
</span></a>
  <a href="calcat/sharp/sharp-techlib.html" class="list-group-item list-group-item-info">Sharp Data Page <span class="glyphicon glyphicon-chevron-right">
</span></a>
  <a href="calcat/soemtron/soemtron-techlib.html" class="list-group-item list-group-item-info">Soemtron Data Page <span class="glyphicon glyphicon-chevron-right">
</span></a>
  <a href="calcat/wang/wang-techlib.html" class="list-group-item list-group-item-info">Wang Data Page <span class="glyphicon glyphicon-chevron-right">
</span></a>
</div>
</div>
</div>
  <div class="col-md-4">
  <h3 class="text-center text-info">Computer-Specific Data</h3>
  <div id="MainMenu">
  <div class="list-group panel">
  <a href="compcat/ABC/AiABC-techlib.html" class="list-group-item list-group-item-info">ABC Computer Data Page <span class="glyphicon glyphicon-chevron-right">
</span></a>
</div>
</div>
</div>
  <div class="col-md-4">
  <h3 class="text-center text-info">Technology</h3>
  <div class="list-group panel">
  <a href="#logic" class="list-group-item list-group-item-info" data-toggle="collapse" data-parent="#MainMenu">Electronic Logic <span class="caret">
</span></a>
  <div class="collapse" id="logic"><a href="" class="list-group-item">Diode &amp; Transistor Logic</a> <a href="" class="list-group-item">Small Scale Integration</a> <a href="" class="list-group-item">Medium Scale Integration</a></div>
</div>
  <div class="list-group panel">
  <a href="#memory" class="list-group-item list-group-item-info" data-toggle="collapse" data-parent="#MainMenu">Memory&nbsp;<span class="caret">
</span></a>
  <div class="collapse" id="memory"><a href="" class="list-group-item">Delay Lines</a> <a href="" class="list-group-item">Magnetic: Cores and Disks</a> <a href="" class="list-group-item">Integrated Circuit RAM</a></div>
</div>
  <div class="list-group panel">
  <a href="#displays" class="list-group-item list-group-item-info" data-toggle="collapse" data-parent="#MainMenu">Displays <span class="caret">
</span></a>
  <div class="collapse" id="displays"><a href="" class="list-group-item">CRT Vector Drawing</a> <a href="" class="list-group-item">Nixie Tubes &amp; Panaplex Panels</a></div>
</div>
</div>
</div>
