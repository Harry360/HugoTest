+++
title = "DoPECC: Vintage Computers"
description = "A small collection of vintage computers fromt the 1960s to 1980s"
date = 2017-10-15T22:26:56+11:00
draft = true
+++



# The Dawn of Personal Computing

<div class="row">
  <p></p>
  <div class="col-md-12">
  <p></p>
  <p class="text-justify">The Dawn of Personal
Computing refers to that period when complete computers became available to
individuals on an exclusive basis. Aside from the benefits of applying computing
resources to more and more fields of work, this led to an explosion in the
number of people who had intimate knowledge of computers, how they worked and
what they could do. Computers were no longer the preserve of a technical elite,
and a community of computer enthusiasts could begin to develop.</p>
<p class="text-justify">Two developments in the early 1970s ushered in the dawn age
for personal computing: </p>
<ul>
<li>First was the development of the
microprocessor, which in turn led to the introduction of small business
computers and dedicated hobbyist home computer systems. Small business computers
brought a professional style of hardware and software to individual users while
the home computers of the 1970s allowed enthusiasts to gain a close
understanding of the design and construction of microprocessor based
systems.</li>
<li>Second was the movement of obsolete 1960s computer hardware
into the hands of schools and enthusiasts. This allowed the recipients to gain
experience and knowledge of professionally engineered hardware and
software.</li>
</ul>
This site presents just a few examples of such systems and
machines, examples that happen to be of personal interest.
<p></p>
</div>
</div>

<div class="row">
  <h2 class="text-center text-info">Computer Catalog</h2>
  <p>
</p>
  <div class="col-md-9">
  <h4><a href="compcat/ABC/AiABC.html">Ai
Electronics</a></h4>
  <p class="text-justify">Ai Electronics is one of many
little known non-US developers of early personal computers. The Ai's ABC series
are a good example of the high quality of work that was done outside the US. The
ABC machines had advanced hardware design, were built to a high standard and had
a very extensive software library.</p>
  <p class="text-justify">There is very
little information available about these machines in the English language
internet and this site seeks to gather and preserve what may be found, to
accompany DoPECC's two machines from the ABC series.</p>
  <p class="text-justify
text-success">The original software environment for these ABC machines is
missing. Anyone with any information or any items of original Ai software is
urged to make contact with DoPECC.</p>
  <p></p>
</div>
  <div class="col-md-3">
  <div class="list-group panel">
  <a href="#ai" class="list-group-item
list-group-item-info" data-toggle="collapse" data-parent="#MainMenu">Ai
Electronics <span class="caret">
</span></a>
  <div class="collapse in" id="ai"><a href="compcat/ABC/AiABC.html" class="list-group-item list-group-item-info">Ai
Electronics Overview</a> <a href="compcat/ABC/AiABC-1dsn.html" class="list-group-item">Ai Electronics ABC-24</a> <a href="compcat/ABC/AiABC-1dsn.html" class="list-group-item">Ai Electronics
ABC-26</a></div>
</div>
</div>
</div>

<div class="row">
  <div class="col-md-9">
  <h4><a href="compcat/NCR/NCR.html">NCR Computers</a></h4>
  <p class="text-justify">NCR was an early entrant into the postwar computer and data
processing business. The combination of prewar business that understood the
electromechanical cash register market and wartime technology transfer led NCR
to early success in business data processing. </p>
  <p class="text-justify">During the 1960s NCR developed a number of computers that
fit with DoPECC's interests, in particular the machines based on the 605
small-scale IC processor.</p>
  <p class="text-justify">DoPECC has acquired an NCR
725 which is a nice example of an early 1970s computer and is based on the 605
processor. The 725 is therefore a good candidate for restoration and
preservation.</p>
  <p class="text-justify">The NCR 725 is presented here as a
potential restoration project and DoPECC is currently searching for people who
may be able to contribute information.</p>
  <p></p>
</div>
  <div class="col-md-3">
  <div class="list-group panel">
  <a href="#ncr" class="list-group-item list-group-item-info" data-toggle="collapse" data-parent="#MainMenu">NCR Computers&nbsp;<span class="caret">
</span></a>
  <div class="collapse in" id="monroe"><a href="compcat/NCR/NCR.html" class="list-group-item list-group-item-info">NCR Computers Overview</a> <a href="compcat/NCR/NCR725-1dsn.html" class="list-group-item">NCR 725 Computer</a>
<a href="compcat/NCR/NCR725-2tech.html" class="list-group-item">NCR 605
Processor</a></div>
</div>
</div>
</div>

<div class="row">
  <div class="col-md-9">
  <h4><a href="compcat/monroe/monrobot.html">Monroe Litton</a></h4>
  <p class="text-justify">Monroe was a large and successful US mechanical
calculator company and was able to recognise the significance of electronic
logic and data processing as these technologies developed in the 1950s. Monroe's
electronic calculators are described on this site.</p>
  <p class="text-justify">Monroe also successfully developed small commercial
computers, no doubt recognising that their mechanical calculator business was
also under severe threat by computer technology.</p>
  <p class="text-justify">The
Monrobot XI was one of Monroe's small business computers. This was one of the
first machines that the author had experience with and it has naturally left a
considerable sense of nostalgia. Monrobot machines seem to have been lost and
the author is unaware of any survivors of any model.</p>
  <p class="text-justify">The author's own collection of documents are presented
here, for general interest and for the particular interest of anyone who may
still have an example of this machine.</p>
</div>
  <div class="col-md-3">
  <div class="list-group panel">
  <a href="#monroe" class="list-group-item
list-group-item-info" data-toggle="collapse" data-parent="#MainMenu">Litton
Monroe&nbsp;<span class="caret">
</span></a>
  <div class="collapse in" id="monroe"><a href="compcat/monroe/monrobot.html" class="list-group-item
list-group-item-info">Litton Monroe Overview</a> <a href="compcat/monroe/monrobotXI-1dsn.html" class="list-group-item">Monrobot
XI</a></div>
</div>
</div>
</div>

<div class="row">
  <div class="col-md-9">
  <p class="text-justify text-success"><em>DoPECC is keen to know of any further
examples of hardware, software or technical data for Ai and Monrobot machines.
If any readers have information they may send a message via the About link.</em></p>
</div>
</div>
