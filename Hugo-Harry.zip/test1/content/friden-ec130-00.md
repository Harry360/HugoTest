---
title: "DoPECC: Friden EC 130 Electronic Calculator"
description: "General and Technical Description of the Friden EC 130 Electronic Calculator"
date: 2017-10-16T19:53:41+11:00
draft: true
---
<div class="row">
  <div class="col-md-12">
    <h1 class="text-center"><a href="friden000" class="btn btn-sm btn-info pull-left" role="button">Back to Friden Overview</a>Friden EC 130 Calculator</h1>
  </div>
  <ul class="nav nav-tabs">
    <li class="active"><a href="#Description" data-toggle="tab">Description</a></li>
    <li><a href="#Technology" data-toggle="tab">Technology</a></li>
    <li><a href="#Photos" data-toggle="tab">Photos</a></li>
    <li><a href="/logs/friden-ec130-00">Machine Log</a></li>
    <li><a href="/friden-techlib">Data and Links</a></li>
  </ul>
  <div class="tab-content">
    <div class="tab-pane active" id="Description">  <!-- Tab 1 Description -->
      <div class="col-md-8">
        <p class="text-justify">The Friden EC 130 is a marvellous machine. It arose from a special intersection of circumstances and is utterly a product of its time, born as electronic logic first flowered, and of its place, built by a company expert in mechanical construction and committed to craftsmanship. The EC 130 is an arresting first sight and it still appears modern, over fifty years from its debut. In use it says "quality" at every keypress, the key goes down with a silky swoosh, against a gentle constant resistance. The key locks while the electronics do their work, then there is a soft click and the key rises rapidly and smoothly, ready for the next input. The keys on an EC 130 operate with the same feel as the closing of a luxury car door.</p>
        <p class="text-justify">The special look and feel of an EC 130 cannot be denied and was actually based on business reasons that appeared sound at the time. In the mechanical calculator world skilled operators worked at very high rates without looking at the keyboard, similar to touch typists. The "feel" of the keyboard was very important to these operators and new models with the wrong feel would be received poorly. Friden had long experience in the calculator market and carried this concern for feel through to the EC 130. The EC 130 keyboard is an intricate piece of mechanism and is responsible for the special keyboard action. This attention to detail would have seemed reasonable to Friden but was not shared by people like Dr Wang who judged that once people appreciated the power and economy of electronic calculators they would rapidly forgive a harsh and clicky keyboard. Similarly, Friden no doubt found it easy and natural to design an intricate and beautiful case, while Dr Wang and others judged that a simple box would satisfy the customer once they saw what the calculator could actually do.</p>
        <h4>Operating the EC 130</h4>
        <p class="text-justify">The EC 130 uses Reverse Polish input, and was the first calculator to employ this method. The method takes a bit of time to learn but then provides the means to handle very complex calculations entirely within the calculator, without the need to record intermediate results. Use of Reverse Polish is assisted if the machine's calculation stack can be viewed and this is where the multi-line CRT display becomes very important. Aside from assisting with complex calculations Reverse Polish also simplifies many parts of the electronic logic, thus there are two reasons why Robert Ragen may have adopted this method.</p>
        <p class="text-justify">Once Reverse Polish is understood, the EC 130 is very easy to operate. The decimal place is fixed and is selected on the thumbwheel. Digits are entered directly and Change Sign toggles sign as required. The four arithmetic functions operate on the bottom two numbers in the stack. Enter pushes the input number up the calculation stack and Repeat duplicates the bottom entry, pushing the stack up. Numbers pushed off the top of the stack are lost silently, without error indication. Store and Recall move a number in or out of a separate storage register.</p>
        <h4>Quirks and Errors</h4>
        <p class="text-justify">The EC 130 has a robust arithmetic implementation. Negative numbers and their combinations are handled correctly across all operations. </p>
        <p class="text-justify">Overflow detection is robust, the overflow indicator lights and the keyboard locks until Clear is pressed. Underflow possible with the fixed decimal system and is silent but should be obvious by the all-zero display</p>
        <p class="text-justify">Division by zero causes an endless loop and Clear All must be pressed to terminate it.</p>
        <p class="text-justify"><br><br>The EC 130 is still perfectly usable today. It is fast and free from vices or errors. Reverse Polish with a fully-displayed 4-level stack makes it is quite powerful, as long as the four arithmetic functions are sufficient. It is also good to look at and pleasant to use.</p>
        <p class="text-justify">Continuing to use it regularly seems likely to be a very appropriate tribute to Robert Ragen and his team.</p>
      </div>
      <div class="col-md-4">
        {{< ATC-panelimgmodalpop imgpath="/images/calcs/friden/" imgname="EC130-A" dsn="Friden EC-130" >}}
        {{< ATC-panelimgmodalpop imgpath="/images/calcs/friden/" imgname="EC130-C" dsn="Friden EC-130 Keyboard" >}}
      </div>
    </div>  <!-- Tab 1  Description tab -->
    <div class="tab-pane" id="Technology">  <!-- Tab 2  Technology -->
      <div class="col-md-8">
        <p> </p>
        <h4>Electronics</h4>
        <p>First-generation diode-transistor logic.</p>
        <p></p>
        <h4>Architecture, Memory & Speed</h4>
        <p>14 displayed digits, 1 sign digit and one decimal position digit = 16 digit word</p>
        <p>Digits encoded as a unary bit-stream where each digit has a ten-pulse time window and the digit's value is represented by the position of a pulse within that window. A full register is made up of 16 such time windows and the full set of calculator registers are held in a serial memory that uses a magnetostrictive wire delay line. </p>
        <p>Core memory, 4 registers x 16 digits x 4 bits = 256 cores</p>
        <p>@@kHz master clock, @@mS digit pulse time gives an @@msec digit time, a @@msec register time and requires a @@msec total memory time in order to hold @@ registers.</p>
        <h4>Construction</h4>
        <p class="text-justify">Friden's design and metalworking skills are showcased in the four intricate castings that form the main chassis and the streamlined sheetmetal upper cover. The pieces fold, slide and clip together with just a few screws for final security. There is a secret lock-out that can prevent the power switch from operating, its use requires some technical expertise and it's not clear what the anticipated use was. The secret may be discovered from the photographs, this is left as a puzzle for visitors.</p>
        <p class="text-justify">The electronics cage is a separate subassembly and is divided into two bays with a metal separator that shields the low voltage logic from the high voltage electrostatic CRT (and vice versa). The logic bay houses four plug-in units each composed of two double sided boards that are connected by a spine of jumper wires. The edge connectors are thoughtfully offset to different distances for each module to eliminate insertion errors. This is a nice contrast to the Wang 362SE where any of the 32 identically-sized boards can be plugged into any of the 32 backplane slots! The EC 130 backplane interconnect is a circuit board and there are fat copper busbars for power distribution, the likes of which I have not seen in any other calculator. The second bay in the electronics cage houses the multi-primary mains transformer and the low voltage power supply with series-pass regulators producing +6v and -12v while a big zener mounted on the rear heatsink produces -80v. The 3kV CRT anode voltage is generated by a voltage multiplier that is fed from a dedicated transformer that is in turn driven by its own oscillator. The CRT is mounted above the high voltage generator and is further shielded by its own mu-metal shroud.</p>
        <p class="text-justify">The keyboard is a mechanical masterpiece and distills Friden's experience in precision metalwork for mechanical calculators. It provides elegant tactile feedback for each key motion and it locks when any operation is in progress or if an error occurs. Each key drives a horizontal knifeblade and these blades all extend over a set of seven encoder bars. The bars are spring loaded and each has a complex series of ramps cut along one edge. When a key is pressed its knifeblade bears against a combination of these ramps and displaces the set of encoder bars in a pattern determined by the ramps. The ramp gradient and the loading springs provide the steady tactile feedback to each keystroke. Each encoder bar carries a magnet and the displacement of the bars moves the magnets into a pattern that is unique to each key and is sensed by a series of reed switches. A mechanical latch is tripped when the keystroke reaches its limit, this latch holds the key and encoder bars in place until the electronics sends a 'ready' signal. This signal activates a solenoid which releases the encoder and key with a soft click. Other manufacturers simply put a switch on each key and encoded the results with electronics but Friden evidently rated key "feel" highly and had the in-house expertise to develop this complex mechanical solution. </p>
      </div>
      <div class="col-md-4">
        {{< ATC-panelimgmodalpop imgpath="/images/calcs/friden/" imgname="EC130-U20" dsn="Friden EC-130 with extenders" >}}
        {{< ATC-panelimgmodalpop imgpath="/images/calcs/friden/" imgname="EC130-U11" dsn="Friden EC-130 keyboard" >}}
        {{< ATC-panelimgmodalpop imgpath="/images/calcs/friden/" imgname="EC130-U05a" dsn="Friden EC-130 power lock-out" >}}
      </div>
    </div>  <!-- Tab 2 -->
    <div class="tab-pane" id="Photos">  <!-- Tab 3  Photos -->
      <div class="row">
        <div class="col-md-12">
          <p>&nbsp;</p>
          <h4>Friden EC-130</h4>
          </div>
        <div class="col-xs-6 col-md-3">
          {{< ATC-panelimgmodalpop imgpath="/images/calcs/friden/" imgname="EC130-A" dsn="Friden EC-130 Electronic Calculator" >}}
        </div>
        <div class="col-xs-6 col-md-3">
          {{< ATC-panelimgmodalpop imgpath="/images/calcs/friden/" imgname="EC130-B" dsn="Friden EC-130 CRT display" >}}
        </div>
        <div class="col-xs-6 col-md-3">
          {{< ATC-panelimgmodalpop imgpath="/images/calcs/friden/" imgname="EC130-C" dsn="Friden EC-130 Keyboard" >}}
        </div>
        <div class="col-xs-6 col-md-3">
          {{< ATC-panelimgmodalpop imgpath="/images/calcs/friden/" imgname="EC130-D" dsn="Friden EC-130 Rear" >}}
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <p>&nbsp;</p>
          <h4>Friden EC-130 Construction</h4>
        </div>
        <div class="col-xs-6 col-md-3">
          {{< ATC-panelimgmodalpop imgpath="/images/calcs/friden/" imgname="EC130-U00" dsn="Friden EC-130 Chassis Casting" >}}
          {{< ATC-panelimgmodalpop imgpath="/images/calcs/friden/" imgname="EC130-U05" dsn="Friden EC-130 What's this?" >}}
          {{< ATC-panelimgmodalpop imgpath="/images/calcs/friden/" imgname="EC130-U08" dsn="Friden EC-130 Card Connectors" >}}
        </div>
        <div class="col-xs-6 col-md-3">
          {{< ATC-panelimgmodalpop imgpath="/images/calcs/friden/" imgname="EC130-U01" dsn="Friden EC-130 Chassis Cover Casting" >}}
          {{< ATC-panelimgmodalpop imgpath="/images/calcs/friden/" imgname="EC130-U05a" dsn="Friden EC-130 Power Lockout by rear screw" >}}
          {{< ATC-panelimgmodalpop imgpath="/images/calcs/friden/" imgname="EC130-U09" dsn="Friden EC-130 Backplane" >}}
        </div>
        <div class="col-xs-6 col-md-3">
          {{< ATC-panelimgmodalpop imgpath="/images/calcs/friden/" imgname="EC130-U03" dsn="Friden EC-130 Electronics Cage - Front" >}}
          {{< ATC-panelimgmodalpop imgpath="/images/calcs/friden/" imgname="EC130-U10" dsn="Friden EC-130 Delay Line Memory Module" >}}
          {{< ATC-panelimgmodalpop imgpath="/images/calcs/friden/" imgname="EC130-U11a" dsn="Friden EC-130 Keyboard Encode Fault" >}}
        </div>
        <div class="col-xs-6 col-md-3">
          {{< ATC-panelimgmodalpop imgpath="/images/calcs/friden/" imgname="EC130-U04" dsn="Friden EC-130 Rear fold-down panel" >}}
          {{< ATC-panelimgmodalpop imgpath="/images/calcs/friden/" imgname="EC130-U07" dsn="Friden EC-130 Power Supply under" >}}
          {{< ATC-panelimgmodalpop imgpath="/images/calcs/friden/" imgname="EC130-U11" dsn="Friden EC-130 Keyboard Encode Mechanics" >}}
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <p>&nbsp;</p>
          <h4>Friden EC-130 Circuit Boards</h4>
        </div>
        <div class="col-xs-6 col-md-3">
          {{< ATC-panelimgmodalpop imgpath="/images/calcs/friden/" imgname="EC130-PCB1a" dsn="Friden EC-130 Circuit Board 1 - A side" >}}
          {{< ATC-panelimgmodalpop imgpath="/images/calcs/friden/" imgname="EC130-PCB1b" dsn="Friden EC-130 Circuit Board 1 - B side" >}}
        </div>
        <div class="col-xs-6 col-md-3">
          {{< ATC-panelimgmodalpop imgpath="/images/calcs/friden/" imgname="EC130-PCB2a" dsn="Friden EC-130 Circuit Board 2 - A side" >}}
          {{< ATC-panelimgmodalpop imgpath="/images/calcs/friden/" imgname="EC130-PCB2b" dsn="Friden EC-130 Circuit Board 2 - B side" >}}
        </div>
        <div class="col-xs-6 col-md-3">
          {{< ATC-panelimgmodalpop imgpath="/images/calcs/friden/" imgname="EC130-PCB3" dsn="Friden EC-130 Circuit Board 3 - A side" >}}
          {{< ATC-panelimgmodalpop imgpath="/images/calcs/friden/" imgname="" dsn="Friden EC-130 Circuit Board 3 - No B side" >}}
        </div>
        <div class="col-xs-6 col-md-3">
          {{< ATC-panelimgmodalpop imgpath="/images/calcs/friden/" imgname="EC130-PCB4a" dsn="Friden EC-130 Circuit Board 4 - A side" >}}
          {{< ATC-panelimgmodalpop imgpath="/images/calcs/friden/" imgname="EC130-PCB4b" dsn="Friden EC-130 Circuit Board 4 - B side" >}}
        </div>
      </div>
    </div>  <!-- Tab 3 -->
    <div class="tab-pane" id="DataLinks">
    </div>  <!-- Tab 5 Data Links -->
  </div>  <!-- Tab Content -->
</div>  <!-- Outer Row -->
