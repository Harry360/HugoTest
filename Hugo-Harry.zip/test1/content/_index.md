---
title: "DoPECC: Vintage Calculators and Vintage Computers. Museum Collection, Restoration and Technical Information"
description: "The Dawn of Personal Electronic Calculators and Computers.  A collection of calculators and computers from the 1960s-1970s."
date: 2017-10-14T09:18:42+11:00
draft: true
---
<h1 class="text-center">The Dawn of Personal Electronic Calculators and Computers</h1>
<div class="row">
  <div class="col-md-3">
    <img src="images/calcs/friden/EC130-A-i.jpg" alt="Friden EC 130 Calculator" class="img-responsive">
    <h5 class="text-center"><a href="calcat/friden/fridenEC130-1dsn.html">Friden EC 130 (1964)</a></h5>
  </div>
  <div class="col-md-6">
  <p class="text-justify">The primary aim of this site is to to preserve, display and promote understanding of equipment from the revolutionary period in electronic technology when calculating and computing equipment first became available to individuals.</p>
  <p class="text-justify">The equipment of this period is generally built from very many simple parts - diodes, transistors and (sometimes) basic integrated circuits. The entire circuit can be re-created by careful study, this allows the underlying design to be understood and the engineering solutions to be appreciated and admired. As another collector has said:</p>
  <blockquote><p>"(these machines represent) early calculator history before the advent of modern electronics, in the days when "hands on" engineers thought through the problems and challenges of designing equipment with little resources, to produce the best end product they could"</p></blockquote>
</div>
  <div class="col-md-3">
  <img src="images/calcs/olympia/ORAE415-A-i.jpg" alt="Olympia RAE 4/15 (1964)" class="img-responsive">
  <h5 class="text-center"><a href="calcat/olympia/olympiaRAE415-1dsn.html">Olympia RAE 4/15 (1964)</a></h5>
</div>
  <div class="col-md-12">
  <p class="text-justify">These machines may be quirky and often have peculiar operating features. They can produce wrong results or even go wild if asked to calculate with numbers that are too big, too small or otherwise not to their taste. These quirks and limitations stem from the challenge of little resources referred to above and can surprise or amuse contemporary users who are inclined to take technological correctness for granted.</p>
  <p class="text-justify">A further interesting feature of these machines follows from their construction from simple individual parts: they can be repaired, maintained and kept in working order indefinitely, for the interest and education of those in future. Once the circuit is analysed and the design is understood, failures can be diagnosed and the relevant individual parts can be replaced. The analysis and diagnosis is a nice logical puzzle and the result, a working calculator, is satisfying. </p>
  <p class="text-justify">Modern electronic equipment that is built with complex chips has its design hidden in the chip. The architecture and engineering of such machines cannot be seen, appreciated or understood and from this viewpoint such machines have little technical or educational interest. If a later-generation machine fails and the fault is within a complex chip then it is generally not repairable. The machine is then 'dead' and it ceases to be interesting as a functional object.</p>
  <p></p>
  <h3 class="text-center">Technical Information &amp; Library</h3>
  <p class="text-justify">A further aim of this site is to collect a library of technical information and advice, to be available to anyone with an interest in understanding, repairing or restoring these machines.</p>
  <p class="text-justify">The detailed technical information that is needed to diagnose and repair these machines is now mostly lost but the internet provides a good means to identify and collect what little remains. There is also a small but dedicated community who are reverse engineering these machines in order to derive the required information from scratch and the library hosts some of this work or provides links.</p>
  <p class="text-justify text-success">DoPECC is actively seeking any and all technical information about machines on this site, or similar machines. In seeking to keep these machines operating, circuits and manuals are most helpful. Most of this information has been lost and is very difficult to recreate by reverse engineering. Anyone who may have further any information to contribute is urged to <a href="aboutcontact.html">make contact</a>.</p>
</div>
</div>

<div class="row">
  <div class="col-md-12">
  <p></p>
  <h3 class="text-center">Organisation of this Site</h3>
</div>
  <div class="col-md-4">
  <div class="panel panel-info">
  <div class="panel-heading">
  <h3 class="panel-title"><a href="calculators.html">Calculators <span class="glyphicon glyphicon-chevron-right">
</span></a></h3>
</div>
  <div class="panel-body">
  <img src="calcat/sharp/images/CS20A-A-i.jpg" alt="Sharp Compet CS-20A Calculator" class="img-responsive">
  <h5 class="text-center">Hayakawa (Sharp) Compet CS-20A (1965)</h5>
</div>
</div>
</div>
  <div class="col-md-4">
  <div class="panel panel-info">
  <div class="panel-heading">
  <h3 class="panel-title"><a href="computers.html">Early Computers</a> <span class="glyphicon glyphicon-chevron-right">
</span></h3>
</div>
  <div class="panel-body">
  <img src="images/ABC-24gen.jpg" alt="Ai Electronics ABC-24 Computer" class="img-responsive">
  <h5>Ai Electronics ABC-24 Computer (1985)</h5>
</div>
</div>
</div>
  <div class="col-md-4">
  <div class="panel panel-info">
  <div class="panel-heading">
  <h3 class="panel-title"><a href="techlib.html">Technical Information &amp; Library</a> <span class="glyphicon glyphicon-chevron-right">
</span></h3>
</div>
  <div class="panel-body">
  <img src="images/ABC-24gen.jpg" alt="Ai Electronics ABC-24 Computer" class="img-responsive">
</div>
</div>
</div>
</div>
