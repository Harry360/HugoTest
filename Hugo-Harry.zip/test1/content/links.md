+++
title = "TODO: Unique Page Title"
description = "TODO: meta-description"
date = 2017-10-16T13:39:42+11:00
draft = true
+++

# Other Vintage Calculator, Computer & Technology Sites

<div class="row">
  <div class="col-md-12">
  <p></p>
  <p class="text-justify">There are a surprising number of very good sites with excellent information that will be enjoyed by anyone who has found this site to be of some interest. The sites listed below are those with significant machines or information relevant to the Dawn Period.</p>
  <p></p>
  <h4><a href="http://www.oldcalculatormuseum.com" target="_blank">The Old Calculator Web Museum</a></h4>
  <p>An excellent and comprehensive site, covering the dawn-era to the modrn era. Many interesting and rare machines with excellent detailed information about each. Highly recommended.</p>
  <p></p>
  <h4><a href="http://www.johnwolff.id.au" target="_blank">John Wolff's Web Museum</a></h4>
  <p>This site is dedicated to preserving engineering heritage in calculators and mechanical music. The calculators section contains a wide range of mechanical calculators as well as dawn and mid-era electronic machines. There is a large amount of detailed information about the design, operation and maintenance of mechanical calulators. Highly recommended.</p>
  <p></p>
  <h4><a href="http://www.vintagecalculators.com" target="_blank">Vintage Calculators Web Museum</a></h4>
  <p>This site has a British emphasis and provides a nice added perspective to the more common US-based calculator history. Mechanical and electronic calculators are included, with a lot of interesting data about the history of the development of important machines.</p>
  <p></p>
  <h4><a href="http://www.calcuseum.com" target="_blank">Calcuseum</a></h4>
  <p>This site is a tour-de-force, indexing over 20,000 calculators with detailed information. It is probably the definitive site for identification of machines from the 1960s to the 1990s. A wealth of information.</p>
  <p></p>
  <h4><a href="http://www.leningrad.su/museum" target="_blank">Soviet Digital Electronics Museum</a></h4>
  <p>Sergei Frolov has assembled an excellent collection that illustrates the very different progress of electronic calculator development in the Soviet world. The entire site is very interesting but it is worth a visit just to see the RASA machine - an extraordinary solution to the very real 1960s problem of providing a good display for a desktop calculator.</p>
  <p></p>
  <h4><a href="http://www.wass.net/manuals" target="_blank">Vintage Electronic Calculator Manuals</a></h4>
  <p>An extensive archive of manuals for pre-LCD calculators.</p>
  <p></p>
  <h4><a href="http://www.cs.ubc.ca/~hilpert/eec/index.html" target="_blank">Early Electronic Calculator Technology Reference</a></h4>
  <p>This is perhaps the best site for detailed technical information on the architecture and electronic construction of first-generation machines. Brent Hilpert has done an extraordinary amount of painstaking work to reverse engineer, understand and document a large number of machines. Essential material to study for anyone seriously interested in understanding and maintaining first-generation machines. For those contemplating the reverse engineering path, inspiring to see that it can be done and the valuable information that will be obtained.</p>
  <p></p>
  <h4><a href="http://home.wxs.nl/~janvdv/wang/wangmuseum.htm" target="_blank">Wang Small Museum</a></h4>
  <p>Jan van de Veen in the Netherlands has published a very nice site that concentrates on Wang machines from calculators of the late 1960s to desktop computers of the 1980s. He has an excellent library of Wang technical documents and DoPECC is grateful to him for his generous help with these documents.</p>
  <p></p>
</div>
</div>
