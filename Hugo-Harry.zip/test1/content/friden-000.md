+++
title = "DoPECC: Friden Calculators"
description = "Vintage Friden Electronic Calculators"
date = 2017-10-16T18:04:12+11:00
draft = true
+++
<h1 class="text-center">Friden Electronic Calculators - Overview</h1>
<div class="row">
  <div class="col-md-12">
    <p class="text-justify">Carl Friden was a gifted mecanical engineer, early in his life he worked for the Marchant calculator company but by the 1930s he was working on his own mechanical inventions, including a greatly improved mechanical calculator. The Friden Calculating Machine Company was established in 1934 and the improved calculator soon became a great success. By the time of World War II Friden was a leading manufacturer of high-end desktop calculators, and by the 1950s Friden had achieved a mechanical tour-de-force with the Model SRW that could automatically extract square roots.</p>
    <p class="text-justify">In the 1950s Friden recognised the potential of electronic logic, perhaps assisted by its location in San Leandro California, an area soon to become better known as Silicon Valley. Unlike other mechanical calculator companies in the 1950s, Friden did not attempt to enter the emerging computer or data processing businesses but instead set out to apply the new technology of electronic logic to its well-known and well-understood calculator business. One might contrast this approach with that of Singer, described at the bottom of this page.</p>
    <p class="text-justify">Friden appears to have been methodical in its approach to developing an electronic calculator. A major initial problem was the lack of a satisfactory electronic display. Friden addressed this in 1961 by engaging the Stanford Research Institute to explore the problem and in early 1962 they provided a solution in the form of an elecronics package that could draw sequences of digits in lines on the face of a cathode ray tube screen. This was <a href="data/3430095SRIdisplayPatent.pdf" target="_blank">patented</a> and assigned to Friden. Further interesting information about the display development and Friden's general development approach may be found at the <a href="http://oldcalculators.wordpress.com/2009/02/">Old Calculator Museum Blog</a>.</p>
    <p class="text-justify">Friden's second problem was to find a designer for the electronic machine that would be a worthy successor to the Model SRW.</p>
    </div>
  </div>
  <div class="row">
    <div class="col-md-12">
      <h3 class="text-center text-info">Friden Calculators at DoPECC</h3>
    </div>
  </div>
  <div class="row">
    <div class="col-md-8">
      <p></p>
      <h4><a href="/friden-ec130-00">The EC 130 Electronic Calculator</a></h4>
      <p class="text-justify">Friden found their designer in Robert Ragen and their successor machine in his radically modern Model EC 130\. The EC 130 was (nearly) the first solid state electronic calculator on the market. The ANITA machines were already on the market but were vacuum tube based imitations of mechanical calculators. The (screenless, print-only) Olivetti 101 was on the market a few months before the EC 130 but the EC 130 was the groundbreaking machine that announced the arrival of the electronic age. Its results were shown on a glowing blue-green screen, it used Reverse Polish notation, it displayed all four levels of the calculation stack on screen and it was housed in a beautiful case that still says "modern", over fifty year later.</p>
      <p>Robert Ragen is too little known, an unsung hero of the dawn of electronic calculators. He appears to have been a modest and very well-liked indiviual. Further links to interesting information about him are here, here and here. Robert Ragen died in 2012 and an obituary may be found <a href="http://www.legacy.com/obituaries/insidebayarea/obituary.aspx?n=robert-ragen-bob&amp;pid=158717663#fbLoggedOut" target="_blank">here</a>. </p>
      <p class="text-justify">Friden now had a worthy successor to the SRW and the EC 130 soon became very successful. It propelled Friden into the forefront of electronic calculator development in the 1960s, with probably only Wang Laboratories as a serious competitor. The EC 130 was developed further to become the EC 132 with square root extraction and while these two machines were revolutionary at their introduction and stood large in their market, it was only a few years until the rapid pace of electronic development began to render them obsolete.</p>
    </div>
    <div class="col-md-4">
      {{< ATC-panelimgmodalpoplink title="Friden EC 130" link="/friden-ec130-00" imgpath="/images/calcs/friden/" imgname="EC130-A" >}}
    </div>
  </div>
  <div class="row">
    <div class="col-md-8">
      <h4><a href="friden1162-1dsn.html">Friden 1162</a></h4>
      <p class="text-justify">The Friden 1162 was a second generation successor to the EC 130/132, using small scale integration ICs and retaining the CRT display. It was a Friden in house development by Robert Ragen and his team, using the same architecture as the EC 130.</p>
      <p class="text-justify">The 1162 and fellow models in the 1150/1160 series extended the life of the 130 architecture but it was an expensive machine to produce, partly due to intricate, high quality construction but also due to the use of the CRT display. This carried significant benefits by display of the calculation stack but the cost would become an overwhelming disadvantage as progress in electronics drove calculator prices down.</p>
    </div>
    <div class="col-md-4">
      {{< ATC-panelimgmodalpoplink title="Friden 1162" link="/friden-1162-00" imgpath="/images/calcs/friden/" imgname="F1162-A" >}}
    </div>
  </div>
  <div class="row">
  <div class="col-md-8">
  <h4>
  <a href="friden1203-1dsn.html">Friden 1203</a>
</h4>
  <p class="text-justify">The Friden 1203 is a fully Singer-branded machine, and represents the progress of Friden under Singer management.</p>
  <p class="text-justify">The 1203 is a USA-built LSI machine, using a single Rockwell A4540 chip. In this machine the date code is from 1974.</p>
  <p class="text-justify">The 1203 is a fairly generic 4-function, 2-memory calculator. Competition in this market segment was intense in the 1970s and the 1203 machine has little to distinguish it from many competitors.</p>
</div>
  <div class="col-md-4">
    {{< ATC-panelimgmodalpoplink title="Friden 1203" link="/friden-1203-00" imgpath="/images/calcs/friden/" imgname="F1203-A" >}}
  </div>
</div>
<div class="row">
  <div class="col-md-12">
  <h4>Takeover of Friden by Singer, Decline and Fall</h4>
  <p class="text-justify">At around the same time as the EC 130 was under development, the Friden company was bought by the Singer sewing machine company. Singer was seeking avenues to diversify from the sewing machine business and purchased a number of electronics and data processing businesses during the 1950s and 1960s. As the 1960s progressed, Friden's course was increasingly set by its new owners and local development of new products was reduced in favour of purchase from OEM sources, especially from the emerging lower-cost suppliers of Japan. Over time more Friden calculators became externally designed and sourced and a company that once was close to its customers and designed products for their needs became one that simply sold them the products of others. As calculator competition became intense in the 1970s this may have contributed to Friden's deterioration and demise, in contrast to Hewlett Packard where active development of high-end products continued and the company flourished.</p>
  <p class="text-justify">It is disappointing to discover that although Singer bought Friden (and other technology companies) in an effort to diversify, all of these acquisitions failed under Singer's management. Singer itself remained successful in the sewing machine business and is still a major and successful sewing machine company, but all of its technology acquisitions are long gone.</p>
  <p class="text-justify">One can only wonder what may have been if Singer had only stuck to its knitting in the sewing machine business and others with more technological knowledge and insight had been allowed to run Friden and its kin.</p>
</div>
</div>
